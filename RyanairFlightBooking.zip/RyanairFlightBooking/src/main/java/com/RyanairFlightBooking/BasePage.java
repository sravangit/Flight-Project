package com.RyanairFlightBooking;

import java.util.Calendar;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.junit.After;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.google.common.base.*;

import pageObjects.HomePage;

public abstract class BasePage {

	protected WebDriver driver;

	public BasePage(WebDriver driver) {

		this.driver = driver;
	}
	
	


	public void setUpDriver() {

		System.setProperty("webdriver.gecko.driver", "..\\RyanairFlightBooking\\geckodriver.exe");
		driver = new FirefoxDriver();
//		System.setProperty("webdriver.chrome.driver", "..\\RyanairFlightBooking\\chromedriver.exe");
//		driver = new ChromeDriver();
		driver.manage().window().maximize();

	}

	public HomePage navigateToHomePage() {
		setUpDriver();
		driver.navigate().to("https://www.ryanair.com/ie/en/");
		return new HomePage(driver);

	}

	public void quitDriver() {
		driver.quit();
	}

	public boolean retryingFindGetText(By by) {
		boolean result = false;
		int attempts = 0;
		while (attempts < 5) {
			try {
				driver.findElement(by).getText();
				result = true;
				break;
			} catch (StaleElementReferenceException e) {
			}
			attempts++;

		}
		return result;
	}

	public void waitUntilElementPresent(int seconds) {
		driver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
	}

	public void clickElement(String location) {
		driver.findElement(By.id(location));
	}

	public void selectDayFromCalendar() {

		// create a calendar
		Calendar cal = Calendar.getInstance();

		// get the value of all the calendar date fields.

		System.out.println("Calendar's Day: " + cal.get(Calendar.DATE));

		String str = driver.findElement(By.xpath("//ul[@class='days']//li[contains(@class,'today')]//span")).getText();

		int todayDate = cal.get(Calendar.DATE);
		int selectNextDay = todayDate + 1;

		int otherDay= todayDate + 9;

		if (cal.get(Calendar.DATE) == Integer.parseInt(str)) {

			System.out.println("today is:" +todayDate);

			if (todayDate > 20 && todayDate<29) {
				
				driver.findElement(By.xpath("//div[contains(@ng-class,'has-monthly-toggle')]/div/ul/li[2][contains(@class,'calendar-view')]/ul[2]//li/span[contains(text(),'"+selectNextDay+"')]")).click();
			}

			else if(todayDate<=20){

				driver.findElement(By.xpath("//div[contains(@ng-class,'has-monthly-toggle')]/div/ul/li[1][contains(@class,'calendar-view')]/ul[2]//li/span[contains(text(),'"+otherDay+"')]")).click();
			
			
			}
		}
	}


	
	
	public void WaitForElementClick(By by){
		
		(new WebDriverWait(driver, 20)).until(ExpectedConditions.elementToBeClickable(by));
	}
	
	
	public void ExplicitWaitForElementVisible(By by){
		
		(new WebDriverWait(driver, 30)).until(ExpectedConditions.visibilityOfElementLocated(by));
	}
	
	
	public void selectElementWait(String xpathValue, String text){
		
		By byxpath = By.xpath(xpathValue);
		WebElement element = new WebDriverWait(driver,30).until(ExpectedConditions.presenceOfElementLocated(byxpath));
		Select selectElement = new Select(element);
		selectElement.selectByVisibleText(text);
		
	}
	
//  	public void waitForElementVisible(){
//
//		    Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
//		    .withTimeout(30, TimeUnit.SECONDS)
//		    .pollingEvery(5, TimeUnit.SECONDS)
//		    .ignoring(NoSuchElementException.class);
//		 
//		   WebElement element = wait.until(new Function<WebDriver, WebElement>()
//		   {
//			   
//		 
//		    public WebElement apply(WebDriver driver) {
//		 
//		    
//		    return driver.findElement(By.id("foo"));
//		 
//		    }
//		 
//		   });
	
  	}
	




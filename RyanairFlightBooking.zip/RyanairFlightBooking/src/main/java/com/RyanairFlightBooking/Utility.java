package com.RyanairFlightBooking;

import java.io.File;
import java.io.IOException;
import java.util.Random;

import org.codehaus.plexus.util.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import cucumber.api.java.After;


public class Utility {

	
	WebDriver driver;
	
	public static void captureScreenshot() throws IOException{
		
		    
		
		try {
			WebDriver driver=null;
			TakesScreenshot screenshot= (TakesScreenshot)driver;
			File source = screenshot.getScreenshotAs(OutputType.FILE);
									
			FileUtils.copyFile(source, new File("./Screenshots/"+System.currentTimeMillis()+".png"));
		} catch (Exception e) {
			
			System.out.println("Exception while taking screenshot" +e.getMessage());
		}
		
	}
	


}

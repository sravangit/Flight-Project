package stepDefinition;

import java.util.List;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.RyanairFlightBooking.BasePage;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.BookingExtrasPage;
import pageObjects.BookingPaymentPage;
import pageObjects.BookingPricelistPage;
import pageObjects.BookingSeatPage;
import pageObjects.HomePage;
import pageObjects.LoginPage;

public class BookingPaymentSteps {

	WebDriver driver = new FirefoxDriver();
//	WebDriver driver = new ChromeDriver();
	HomePage homepage;
	LoginPage loginpage;
	BookingPricelistPage bookingpricelistpage;
	BookingSeatPage bookingseatpage;
	BookingPaymentPage bookingPaymentpage;
	BookingExtrasPage bookingextraspage;
	
	

	
	@After("@web")
	public void afterScenario() throws Throwable{
		
		driver.manage().deleteAllCookies();
		driver.quit();
	}

	@Given("^user is on the home page$")
	public void user_is_on_the_home_page() throws Throwable {

		homepage = new HomePage(driver);
		homepage.navigateToHomePage();

	}

	@When("^user navigates to Login page$")
	public void user_navigates_to_loginpage() throws Throwable {

		loginpage = homepage.navigateToLoginPage();

	}

	@Then("^user navigates to bookingpricelist page$")
	public void user_navigates_to_bookingpricelistpage() throws Throwable {

		bookingpricelistpage = homepage.navigateBookingPriceListPage();
		

	}

	@Then("^user navigates to booking_seat page$")
	public void user_navigates_to_bookingseatpage() throws Throwable {

		bookingseatpage = bookingpricelistpage.navigateBookingSeatPage();

	}


	
	@When("^user selects a seat and confirms$")
	public void user_selects_a_seat() throws Throwable {

		bookingseatpage.selectSeat();
	}

	@Then("^user navigates to booking_payment page$")
	public void user_navigates_to_bookingpaymentpage() throws Throwable {

		 bookingPaymentpage= new BookingPaymentPage(driver);

	}

	@When("^user logs in successfully with \"(.*?)\" as username and \"(.*?)\" as password$")
	public void user_logs_in_successfully_with_as_username_and_as_password(String arg1, String arg2) throws Throwable {

		loginpage.completeLoginForm(arg1, arg2);

	}
	
	
	@And("^user navigates to booking_extras page$")
	public void user_navigates_to_bookingextraspage() throws Throwable {
		
		bookingextraspage = bookingseatpage.navigateBookingExtrasPage();

		
	}

	@Then("^user navigates to the home page with \"(.*?)\" as login_name and success login message as \"(.*?)\"$")
	public void user_navigates_to_the_home_page_with_as_login_name_and_success_login_message(String arg1, String arg2)
			throws Throwable {
		homepage = loginpage.navigateHomePageAfterLogin();
		homepage.successfulLoginConfirmation(arg2);
		homepage.successfulLoginUser(arg1);

	}

	@When("^user selects one way flight \"(.*?)\" and \"(.*?)\"$")
	public void user_selects_one_way_flight_as_FilghtFrom_and_as_FlightTo(String arg1, String arg2) throws Throwable {

		homepage.selectOneWayFlight(arg1, arg2);

	}

	@Then("^user selects a flight out from the price list$")
	public void user_selects_a_price_from_the_price_list() throws Throwable {
		
		bookingpricelistpage.selectPrice();

	}


	
	
	@Then("^user clicks on Checkout button$")
	public void user_clicks_on_Checkout_button() throws Throwable {

		bookingPaymentpage = bookingextraspage.navigateBookingPaymentPage();

	}
	
	@Then("^user clicks on Paynow button$")
	public void user_clicks_on_Paynow_button() throws Throwable {

		bookingPaymentpage = bookingPaymentpage.clickPaynowButton();

	}

	@Then("^user enters firstname, lastname$")
	public void user_enters_as_firstname_as_lastname_as_mobilenumber(DataTable usercredentials) throws Throwable {
		List<List<String>> data = usercredentials.raw();
		bookingPaymentpage.enterFirstName(data.get(1).get(1));
		bookingPaymentpage.enterLastName(data.get(2).get(1));
		

	}
	
	
	@Then("^user enters \"(.*?)\" as mobilenumber$")
	public void user_enters_as_mobile_number(String arg1) throws Throwable {
		
		bookingPaymentpage = bookingPaymentpage.enterMobileNumber(arg1);

	}

	@When("^user enters invalid \"(.*?)\" as credit card number$")
	public void user_enters_as_credit_card_number(String arg1) throws Throwable {
		
		bookingPaymentpage = bookingPaymentpage.enterInvalidCardNumber(arg1);

	}

	@When("^user selects \"(.*?)\" as credit card$")
	public void selects_as_credit_card(String arg1) throws Throwable {
		
		bookingPaymentpage = bookingPaymentpage.selectCardType(arg1);
		
	}


	@Then("^user should see an error message as \"(.*?)\"$")
	public void user_should_see_an_error_message_as(String arg1) throws Throwable {
	
		bookingPaymentpage = bookingPaymentpage.invalidCardNumberErrorMessage();
	}
	
	
	@And("^Close the browser$")
	public void closeBrowser() throws Throwable {
		
	 
	driver.manage().deleteAllCookies();
	driver.quit();
	 
	
	}

}

package pageObjects;



import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.RyanairFlightBooking.BasePage;
import com.RyanairFlightBooking.Utility;

public class LoginPage extends BasePage{
	
	public LoginPage(WebDriver driver){
		
		super(driver);
	}
	
	public LoginPage completeLoginForm(String userName, String password) throws InterruptedException, IOException{
		
		
		waitUntilElementPresent(10);
		driver.findElement(By.name("emailAddress")).sendKeys(userName);
	 	driver.findElement(By.xpath("//form[@name='$ctrl.loginForm']//div[2]//input[contains(@id,'password')]")).sendKeys(password);
	 	Utility.captureScreenshot();
		return new LoginPage(driver);

	}
	
	
	public HomePage navigateHomePageAfterLogin(){
		driver.findElement(By.xpath("//button//span[2]/span[text()='Log in']")).click();
		waitUntilElementPresent(10);
		return new HomePage(driver);
		
		
		
	}
	
	

}

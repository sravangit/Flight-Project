package pageObjects;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.RyanairFlightBooking.BasePage;

public class BookingPricelistPage extends BasePage{
	
	public BookingPricelistPage(WebDriver driver){
		
		super(driver);
	}
	
	

	
	public BookingPricelistPage selectPrice() throws InterruptedException{
	  
		ExplicitWaitForElementVisible(By.className("biz-popup-benefits"));
		if (driver.findElement(By.xpath("//button[contains(@class,'core-btn-primary core-btn-phone-full')]")).isDisplayed()) {
		//	ExplicitWaitForElementVisible(By.className("biz-popup-benefits"));
			driver.findElement(By.xpath("//button[contains(@class,'core-btn-primary core-btn-phone-full')]")).click();
		}
		
		ExplicitWaitForElementVisible(By.xpath("//div[contains(@class,'core-card centered-card')]"));
		
		driver.findElement(By.xpath("//*[@id='outbound']/div/div[3]/div/flights-table/div[2]/div[1]/div/div[2]/div[3]/div/span/label/span")).click();
	//	driver.findElement(By.xpath("//div[contains(@class,'one-third business')]//div[@class='fare']//span[@class='price']")).click();
	//	driver.findElement(By.xpath("//div[contains(@class,'one-third business')]//div[@class='fare']//span[@class='price']")).click();
		
		return new BookingPricelistPage(driver);
	}
	
	public BookingSeatPage navigateBookingSeatPage() throws InterruptedException{
	//	ExplicitWaitForElementVisible(By.xpath("//button[contains(@ng-click,'vm.postFlight()')]"));
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[contains(@ng-click,'vm.postFlight()')]")).click();
		Thread.sleep(1000);
	//	driver.findElement(By.xpath("//div/button[contains(@class,'core-btn-primary')]")).click();
		return new BookingSeatPage(driver);
		
	}
	
	

}

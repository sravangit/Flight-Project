package pageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.RyanairFlightBooking.BasePage;

public class BookingExtrasPage extends BasePage{

	public BookingExtrasPage(WebDriver driver){
		
		super(driver);
	}
	
	
	public BookingPaymentPage navigateBookingPaymentPage() throws InterruptedException{
		
	    Thread.sleep(2000);
	    driver.navigate().refresh();
	    driver.findElement(By.xpath("//span[text()='Check out']")).click();
		Thread.sleep(1000);
			
		return new BookingPaymentPage(driver);
		
	}
}

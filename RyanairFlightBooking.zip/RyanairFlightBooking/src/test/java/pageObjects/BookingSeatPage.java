package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.RyanairFlightBooking.BasePage;

public class BookingSeatPage extends BasePage{
	
	public BookingSeatPage(WebDriver driver){
		
		super(driver);
	}
	
	public BookingSeatPage selectSeat(){
		
		ExplicitWaitForElementVisible(By.className("seat-map"));
		driver.findElement(By.xpath("//div[@class='seat-map-rows']/div[3][@class='ranimate-seat-rows']/div[6]/span/span[@class='seat-click']")).click();
		clickNextbutton();
		
		return new BookingSeatPage(driver);
		
	}
	
	public void clickNextbutton(){
		
		driver.findElement(By.xpath("//div[@class='button-section']/button")).click();
		
		
		
	}
	
	public BookingExtrasPage navigateBookingExtrasPage() throws InterruptedException{
		
	
		ExplicitWaitForElementVisible(By.className("confirm-seats-title"));		
		driver.findElement(By.xpath("//div[@class='button-section']/button")).click();
			
		return new BookingExtrasPage(driver);
	}

}

package pageObjects;

import org.apache.logging.log4j.util.Chars;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.RyanairFlightBooking.BasePage;

import junit.framework.Assert;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class BookingPaymentPage extends BasePage {
	
	public BookingPaymentPage(WebDriver driver){
		
		super(driver);
		
	
	}

	
	public BookingPaymentPage enterFirstName(String firstName) throws InterruptedException{
		

        selectElementWait("//select[contains(@id,'title')]","Mr");
		driver.findElement(By.xpath("//input[contains(@id,'firstName')]")).sendKeys(firstName);

		return new BookingPaymentPage(driver);
	}
	
	public BookingPaymentPage enterLastName(String lastName){
		driver.findElement(By.xpath("//input[contains(@id,'lastName')]")).sendKeys(lastName);
		return new BookingPaymentPage(driver);
	}
	
	public BookingPaymentPage enterMobileNumber(String mobileNumber){
		
		Select number = new Select(driver.findElement(By.name("phoneNumberCountry")));
		number.selectByVisibleText("Ireland");
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(mobileNumber);
		return new BookingPaymentPage(driver);
	}
	
public BookingPaymentPage enterInvalidCardNumber(String cardNumbers){
		
		driver.findElement(By.xpath("//input[contains(@id,'cardNumber')]")).sendKeys(cardNumbers);

		return new BookingPaymentPage(driver);

	}

public BookingPaymentPage selectCardType(String cardTypes){
	
	Select cardOption = new Select(driver.findElement(By.name("cardType")));
	cardOption.selectByVisibleText(cardTypes);
	return new BookingPaymentPage(driver);
	
}
	

public BookingPaymentPage clickPaynowButton(){
	
	driver.findElement(By.xpath("//button[contains(text(),'Pay Now')]")).click();

	return new BookingPaymentPage(driver);
}

public BookingPaymentPage invalidCardNumberErrorMessage(){
	
	String expectedValue = "Card number is invalid";
	String invalidCardNumber= driver.findElement(By.xpath("//ul[@class='ng-active']/li/span")).getText();
	
	Assert.assertEquals(expectedValue, invalidCardNumber);
	return new BookingPaymentPage(driver);
}
	
}

package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.RyanairFlightBooking.BasePage;

import junit.framework.Assert;

public class HomePage extends BasePage {

	public HomePage(WebDriver driver) {
		super(driver);
	}

	@SuppressWarnings("deprecation")
	public LoginPage navigateToLoginPage() {
		driver.findElement(By.id("myryanair-auth-login")).click();
		waitUntilElementPresent(10);
		String actual = driver
				.findElement(By.xpath("//div[2][contains(@class,'last-tab')]/div[contains(@class,'signup-home')]"))
				.getText();
		Assert.assertEquals("Log in", actual);
		return new LoginPage(driver);
	}

	@SuppressWarnings("deprecation")
	public HomePage successfulLoginConfirmation(String successMessage) {
		if (retryingFindGetText(By.xpath("//div[contains(@class,'callout-popup-content')]//strong"))) {
			String str = driver.findElement(By.xpath("//div[contains(@class,'callout-popup-content')]//strong"))
					.getText();
			Assert.assertEquals(successMessage, str);
		}
		return new HomePage(driver);
	}

	@SuppressWarnings("deprecation")
	public HomePage successfulLoginUser(String userName) {

		ExplicitWaitForElementVisible(By.className("username"));
		String actual = driver.findElement(By.className("username")).getText();
		Assert.assertEquals(userName, actual);
		return new HomePage(driver);
	}

	public HomePage selectOneWayFlight(String from, String to) {

		// selecting the type of journey like oneway or return
		ExplicitWaitForElementVisible(By.id("lbl-flight-search-type-one-way"));
		driver.findElement(By.id("lbl-flight-search-type-one-way")).click();

		// entering the departure location
		driver.findElement(By.xpath("//div[@class='disabled-wrap']/input[contains(@placeholder,'Departure airport')]"))
				.click();
		driver.findElement(By.xpath("//div[@class='disabled-wrap']/input[contains(@placeholder,'Departure airport')]"))
				.sendKeys(from);

		// entering the destination location
		driver.findElement(
				By.xpath("//div[@class='disabled-wrap']/input[contains(@placeholder,'Destination airport')]")).click();
		driver.findElement(
				By.xpath("//div[@class='disabled-wrap']/input[contains(@placeholder,'Destination airport')]"))
				.sendKeys(to);

		// click continue button to see the calendar for selecting dates
		driver.findElement(By
				.xpath("//div[3][contains(@class,'col-flight-search-right')]//button[contains(@class,'core-btn-big')]//span"))
				.click();
		driver.findElement(By
				.xpath("//div[3][contains(@class,'col-flight-search-right')]//button[contains(@class,'core-btn-big')]//span"))
				.click();

		// select date for departure from the calendar
		driver.findElement(
				By.xpath("//div[contains(@class,'date-input')]//div[contains(@class,'select-date placeholder')]"))
				.click();
		// driver.findElement(By.xpath("//li[@class='today']")).click();
		selectDayFromCalendar();

		return new HomePage(driver);
	}

	public BookingPricelistPage navigateBookingPriceListPage() {

		driver.findElement(By.xpath("//div[3][contains(@class,'col-flight-search-right')]//button[2][contains(@class,'core-btn-big')]//span")).click();

		
		// ExplicitWaitForElementVisible(By.className("biz-popup-benefits"));
		// driver.findElement(By.xpath("//button[contains(@class,'core-btn-primary
		// core-btn-phone-full')]")).click();
		return new BookingPricelistPage(driver);

	}

}

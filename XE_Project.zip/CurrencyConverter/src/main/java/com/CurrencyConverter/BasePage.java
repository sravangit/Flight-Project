package com.CurrencyConverter;

import java.sql.Time;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import pageObjects.HomePage;

public abstract class BasePage {

	public WebDriver driver;

	public BasePage(WebDriver driver) {

		this.driver = driver;
	}

	public void setUpDriver(String browserName) {
		System.setProperty("webdriver.gecko.driver", "..\\CurrencyConverter\\geckodriver.exe");

		if (browserName.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		}

		else if (browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "..\\CurrencyConverter\\chromedriver.exe");

			driver = new ChromeDriver();
		}

		else if (browserName.equalsIgnoreCase("IE")) {
			driver = new InternetExplorerDriver();
		}

		driver.manage().window().maximize();

	}

	public HomePage navigateToHomePage() {
		setUpDriver("firefox");
		driver.navigate().to("http://www.xe.com/currencyconverter/");
		return new HomePage(driver);

	}

	


	// explicitwait
	public WebElement waitForElementPresence(int time, By locator) {
		WebElement myDynamicElement = (new WebDriverWait(driver, time))
				.until(ExpectedConditions.presenceOfElementLocated(locator));
		return myDynamicElement;
	}

	public void waitUntilElementPresent(int seconds) {
		driver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
	}







}

package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.CurrencyConverter.BasePage;

public class HomePage extends BasePage {


	By currencyFromDropdown = By.id("from_sc");
	
	By currencyToDropdown = By.id("to_sc");

	By textField = By.id("amount");

	By button = By.id("ucc_go_btn_svg");


	public HomePage(WebDriver driver) {
		super(driver);
		
	}

	public void currencyFrom(String fromValue) {

		WebElement element = waitForElementPresence(30, currencyFromDropdown);
		element.click();

		driver.findElement(By.xpath("//ul[contains(@id,'from_scroller')]//li[contains(text(),'"+fromValue+"')]")).click();
	

	}

	public void currencyTo(String toValue) {

		WebElement element = waitForElementPresence(30, currencyToDropdown);
		element.click();

		driver.findElement(By.xpath("//ul[contains(@id,'to_scroller')]//li[contains(text(),'"+toValue+"')]"))
				.click();
		

	}

	public void enterValue(String value) {

		WebElement element = waitForElementPresence(30, textField);
		element.sendKeys(value);

		
	}

	public ResultPage clickConvert() {

		WebElement element = waitForElementPresence(30, button);
		element.click();
		return new ResultPage(driver);

	}

}

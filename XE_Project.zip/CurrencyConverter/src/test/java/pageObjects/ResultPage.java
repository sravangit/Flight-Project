package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.CurrencyConverter.BasePage;

import junit.framework.Assert;

public class ResultPage extends BasePage{
	
	
	
	public ResultPage(WebDriver driver){
		super(driver);
	}
	
	
	public ResultPage checkTitle() throws InterruptedException{
		
		
		String actualTitle= driver.getTitle();
		String expectedTitle= "XE Currency Converter - Live Rates";
		Assert.assertEquals(expectedTitle, actualTitle);
		return PageFactory.initElements(driver, ResultPage.class);
	}
	
		
	public ResultPage CurrencyValue(){
		
		waitForElementPresence(30,By.className("uccResultUnit"));
		String value= driver.findElement(By.className("uccResultUnit")).getText();
	
		String newValue = value.substring(8, 16);
		System.out.println(newValue);
		
		//expected current currency exchange rate from Euro to Pound
		Double expectedValue= Double.parseDouble(newValue);
		

	
		WebElement element = driver.findElement(By.id("amount"));
		String strValue= element.getAttribute("value");
		
		Double doubleValue= Double.parseDouble(strValue);
		System.out.println(doubleValue);
		Double expectedcurrencyValue= doubleValue*expectedValue;
		
		String strnewValue = expectedcurrencyValue.toString();
		String substrValue= strnewValue.substring(0, 5);
        Double expectedCurrencyExchangeValue = Double.parseDouble(substrValue);
		
		
		
    	//actual current currency exchange rate from Euro to Pound
		String actValue = driver.findElement(By.className("uccResultAmount")).getText();
		String newActValue= actValue.substring(0, 5);
		Double actualCurrencyExchangeValue = Double.parseDouble(newActValue);
		
		
		Assert.assertEquals("the value is not expected", expectedCurrencyExchangeValue, actualCurrencyExchangeValue);
		return PageFactory.initElements(driver, ResultPage.class);
		
	}
	
	
	

}

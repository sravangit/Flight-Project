package runner;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import cucumber.api.CucumberOptions;
import cucumber.api.java.After;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resource", glue = { "stepDefinition" }, tags = {"@web"},  format = { "pretty",
		"html:target/html/" }, plugin = {"junit:target/html/report.xml"})




public class TestRunner {
	


}



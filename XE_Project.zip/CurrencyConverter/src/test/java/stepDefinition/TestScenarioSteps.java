package stepDefinition;

import org.junit.After;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterTest;

import com.CurrencyConverter.BasePage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObjects.HomePage;
import pageObjects.ResultPage;

public class TestScenarioSteps {
	
	
    WebDriver driver;
	
    BasePage basepage;
	HomePage homepage = new HomePage(driver);
	ResultPage resultpage= new ResultPage(driver);
	
	
	@Given("^user is on the home page$")
	public void user_is_on_the_home_page() throws Throwable {
		
	    homepage.navigateToHomePage();
	}

	@When("^user selects \"(.*?)\" as the currency from$")
	public void user_selects_as_the_currency_from(String arg1) throws Throwable {
		homepage.currencyFrom(arg1);
	}

	@When("^user selects \"(.*?)\" as the currency to$")
	public void user_selects_as_the_currency_to(String arg1) throws Throwable {
	    
		homepage.currencyTo(arg1);
	}

	@When("^user enters value as \"(.*?)\"$")
	public void user_enters_value_as(String arg1) throws Throwable {
	   
		 homepage.enterValue(arg1);
	}

	@When("^user clicks \"(.*?)\" button$")
	public void user_clicks_button(String arg1) throws Throwable {
		resultpage = homepage.clickConvert();
	    
	}

	@Then("^user navigates to result page$")
	public void user_navigates_to_result_page() throws Throwable {
	     resultpage.checkTitle();
	}

	@Then("^the currency is displayed as expected$")
	public void the_currency_is_displayed_as_expected() throws Throwable {
		 resultpage.CurrencyValue();
	}
	
		
	
}

### the results for this project test is stored under ..CurrencyConverter\target\html\index.html

## the screenshot for the junit test results is stored under ....CurrencyConverter\target\html\results.jpg

## the junit results can be viewed by opening  "TestRunner 20170119-040853.xml" file under ....CurrencyConverter\target\html


## to run the test right click on the TestRunner.java file that is in "runner" package and select as JUnit Test